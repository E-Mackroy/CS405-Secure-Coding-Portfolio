// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits
#include <type_traits>  // type traits for signed/unsigned/floating checks
#include <cmath>        // std::isinf
#include <string>       // std::string
#include <typeinfo>     // typeid

// ======================================================================
// Helpers to check for overflow/underflow without performing it
// ======================================================================
template <typename T>
bool will_add_overflow(T a, T b) {
    if constexpr (std::is_floating_point_v<T>) {
        long double r = static_cast<long double>(a) + static_cast<long double>(b);
        return std::isinf(static_cast<double>(r));
    }
    else if constexpr (std::is_unsigned_v<T>) {
        using Lim = std::numeric_limits<T>;
        return (b > 0) && (a > Lim::max() - b);
    }
    else { // signed integers
        using Lim = std::numeric_limits<T>;
        if (b > 0) return a > Lim::max() - b;
        if (b < 0) return a < Lim::min() - b;
        return false;
    }
}

template <typename T>
bool will_sub_underflow_or_overflow(T a, T b) {
    if constexpr (std::is_floating_point_v<T>) {
        long double r = static_cast<long double>(a) - static_cast<long double>(b);
        return std::isinf(static_cast<double>(r));
    }
    else if constexpr (std::is_unsigned_v<T>) {
        // unsigned subtraction underflows if b > a
        return b > a;
    }
    else { // signed integers
        using Lim = std::numeric_limits<T>;
        if (b > 0) return a < Lim::min() + b;   // a - b < min
        if (b < 0) return a > Lim::max() + b;   // a - b > max
        return false;
    }
}

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// Now returns bool to notify caller of success/failure,
/// and writes the result to 'out' only on success.
/// </summary>
template <typename T>
bool add_numbers(T const& start, T const& increment, unsigned long int const& steps, T& out)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        if (will_add_overflow<T>(result, increment)) {
            // notify caller: addition blocked
            return false;
        }
        result = static_cast<T>(result + increment);
    }

    out = result;
    return true;
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
/// Now returns bool to notify caller of success/failure,
/// and writes the result to 'out' only on success.
/// </summary>
template <typename T>
bool subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps, T& out)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        if (will_sub_underflow_or_overflow<T>(result, decrement)) {
            // notify caller: subtraction blocked
            return false;
        }
        result = static_cast<T>(result - decrement);
    }

    out = result;
    return true;
}


//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character. 

template <typename T>
void test_overflow()
{
    // TODO text kept for reference.

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    // First run: should be safe
    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    {
        T result{};
        bool ok = add_numbers<T>(start, increment, steps, result);
        if (ok) {
            std::cout << +result << std::endl;
        }
        else {
            std::cout << "[blocked: overflow/underflow detected]" << std::endl;
        }
    }

    // Second run: would overflow; we block and inform the user
    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    {
        T result{};
        bool ok = add_numbers<T>(start, increment, steps + 1, result);
        if (ok) {
            std::cout << +result << std::endl;
        }
        else {
            std::cout << "[blocked: overflow/underflow detected]" << std::endl;
        }
    }
}

template <typename T>
void test_underflow()
{
    // TODO text kept for reference.

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step (result should be: start - (increment * steps))
    const T decrement = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    // First run: should be safe
    std::cout << "\tSubtracting Numbers Without Overflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    {
        T result{};
        bool ok = subtract_numbers<T>(start, decrement, steps, result);
        if (ok) {
            std::cout << +result << std::endl;
        }
        else {
            std::cout << "[blocked: overflow/underflow detected]" << std::endl;
        }
    }

    // Second run: would underflow; we block and inform the user
    std::cout << "\tSubtracting Numbers With Overflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    {
        T result{};
        bool ok = subtract_numbers<T>(start, decrement, (steps + 1), result);
        if (ok) {
            std::cout << +result << std::endl;
        }
        else {
            std::cout << "[blocked: overflow/underflow detected]" << std::endl;
        }
    }
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Undeflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    //  create a string of "*" to use in the console
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
